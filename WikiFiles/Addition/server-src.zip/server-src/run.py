#!/usr/bin/env python2
# -*- coding: utf-8 -*
import multiprocessing
import datetime, re, time, urllib, cookielib
import urllib2

interval = 60
svr_addr = "115.156.135.252"
username = "D201234567"
password = "123456"
servername = ["de69", "de75", "de79", "de82"]
cookies_file = '.cookies'
url = "http://" + svr_addr + "/dcms/"
urlapply = url + "/applyins.php?ins_id="
postDict = {
    'username': username,
    'password': password,
    'submit': 'login'
}


def write2file(filename, str):
    fp = open(filename, 'a+')
    fp.writelines(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f') + str + "\n")
    fp.close()


def testping(url):
    req1 = urllib2.Request(url)
    try:
        urllib2.urlopen(req1)
        return True
    except urllib2.URLError as e:
        write2file("log/error.log", e.reason)
        return False


def worker(servername, url, urlapply, postDict, filename, interval):
    while True:
        if testping(url):
            cookie = cookielib.MozillaCookieJar(filename)
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
            postdata = urllib.urlencode(postDict)

            opener.open(url + 'userlogin.php', postdata)
            cookie.save(ignore_discard=True, ignore_expires=True)
            result = opener.open(url + 'index.php', postdata)
            res = result.read()
            res = re.findall('<table>(.+?)</table>', res)
            res = re.findall('<td>(.+?)</td>', res[0])
            for vms in res:
                name = re.findall(r'blank">(.+?)</a>', vms)[0]
                for svr in servername:
                    if svr == name:
                        if re.findall(r'color="(.+?)">', vms)[0] == 'red':
                            write2file("log/run.log", svr + " has been occupied!")
                        else:
                            postDict2 = {
                                'sel_num': '12',
                                'ins_id': svr
                            }
                            postdata = urllib.urlencode(postDict2)
                            ret = opener.open(urlapply + svr, postdata)
                            if ret is not None:
                                write2file("log/run.log", "Application for " + svr \
                                           + " has been submitted successfully!")
        time.sleep(interval)


if __name__ == "__main__":
    p = multiprocessing.Process(target=worker, args=(servername, url, urlapply, postDict, cookies_file, interval))
    p.start()
